# Tempo LDZ para Android TV

Aplicativo em tela cheia para Android TV 8.0 (API 26) ou superior. Carrega
https://ludezam.github.io/tempoLDZ/ e recebe as atualizações publicadas no site.
Precisa de internet e de WebView compatível com o site.

## APK de teste

Arquivo: `outputs/Tempo-LDZ-TV-1.4-teste.apk`.
Pacote: `br.com.ldz.tempotv`, versão 1.4, minSdk 26, targetSdk 34.

Na primeira abertura, busque a cidade desejada. Uma busca que alterar o nome da
cidade é guardada no armazenamento local da WebView e repetida ao abrir o app.
Menu abre Configurações. Use “Buscar outra cidade” para alterar o local salvo e “Buscar atualizações do aplicativo” para consultar a release mais recente no GitHub. Setas navegam, OK ativa e Voltar pede
confirmação para sair. No campo de cidade, OK abre o teclado e seta para baixo
leva ao botão de busca. Não inicia automaticamente ao ligar a TV.

## Ferramentas disponíveis neste computador

O arquivo local `tools.local.json` aponta para o JDK 17 e SDK Android 34 usados
pelo FreeMyTV em `C:/Users/ludez/Documents/Codex/tools/android-build-tools`, e para
o ADB em `C:/Users/ludez/Documents/Codex/tools/adb.ps1`.
As ferramentas de compilacao ficam na pasta compartilhada Codex/tools; as chaves de assinatura foram preservadas.

Para recompilar no PowerShell, dentro desta pasta:

```powershell
.\build-apk.ps1
```

O script compila Java, gera DEX, empacota recursos, alinha, assina e verifica o APK.
Não requer Gradle nem downloads. A assinatura de teste fica em
`.android/tempo-ldz-debug.keystore`. Preserve esse arquivo para atualizar a
instalação mantendo a cidade salva. Ele é ignorado pelo Git.

O acesso ao ADB também tem um atalho, sem alterar o PATH do computador:

```powershell
.\adb.ps1 devices -l
.\adb.ps1 -s 192.168.1.3:5555 install -r .\outputs\Tempo-LDZ-TV-1.4-teste.apk
.\adb.ps1 -s 192.168.1.3:5555 shell am start -n br.com.ldz.tempotv/.MainActivity
```

O endereço acima é o da TV conectada durante o teste; ajuste se mudar.
Em outro computador, copie `tools.example.json` para `tools.local.json` e ajuste
os caminhos. São necessários JDK 17, plataforma android-34 e build-tools 34.0.0.

## Validação em 8 de novembro de 2026

- Compilação Java e DEX concluída; sintaxe do JavaScript verificada.
- Assinaturas APK v2/v3 e alinhamento verificados pelas ferramentas Android.
- Manifesto verificado: Android 8+, launcher Android TV e tela touch opcional.
- Instalação via ADB concluída na Smart TV conectada, Android 11 / API 30.
- Activity aberta com sucesso; captura confirmou site e pedido de cidade.
- Botão OK no campo abriu o teclado virtual da TV.
- Capturas: `outputs/primeira-abertura-tv.png` e `outputs/teclado-tv.png`.

Ainda validar busca meteorológica, persistência da cidade após reabrir, radar e
recuperação de conexão. Nenhuma cidade foi escolhida durante o teste.
Links para sites externos são bloqueados nesta versão. O radar incorporado
permanece no site e depende do provedor externo e da WebView.

## Alternativas de compilação

O projeto Gradle continua disponível para Android Studio/Gradle 8.9 (JDK 17).
Ainda não inclui Gradle Wrapper; com Gradle instalado, execute
`gradle wrapper --gradle-version 8.9`. Configure o SDK em `local.properties`
ou ANDROID_HOME. `gradle assembleDebug` gera `app/build/outputs/apk/debug/app-debug.apk`.
Essa alternativa usa a chave debug padrão do Gradle, diferente da chave do script.

O workflow `.github/workflows/build-apk.yml` também permite gerar um APK no
GitHub Actions. Ele foi preparado, mas não foi enviado nem executado.
Para distribuição permanente, use uma chave de release própria e preservada.

## Versão 1.1

Removidos os links IPMet e Satélite GOES no aplicativo. A busca agora abre em um painel pela lupa no topo ou pelo botão Menu. Após uma busca bem-sucedida, o painel e o teclado são fechados e a previsão volta ao início. A cidade salva também abre com a página no topo. O site público não foi modificado.


Teste da versão 1.1 na TV: cidade Catanduva restaurada, previsão no topo e lupa visível. Lupa abriu o painel; busca repetida pela mesma cidade fechou o painel e voltou ao topo, com teclado fechado.



## Versão 1.2

Layout responsivo para TV 16:9, incluindo 1920x1080: clima e informações à esquerda, radar à direita, Atualizar embaixo. Depois de focar Atualizar, seta para baixo abre a segunda tela, com 12 cards em duas linhas e informações meteorológicas. Seta para cima retorna. Removidos desfoques e fundos animados no aplicativo para reduzir a carga gráfica. O radar continua usando a animação do provedor. A cidade e as configurações são preservadas.


Validação 1.2 na TV Android 11: primeira tela com clima e radar lado a lado; duas setas para baixo a partir da lupa abriram a previsão em grade de 12 cards. Capturas em outputs/painel-1.2-tv.png e outputs/previsao-1.2-tv.png. Layout validado na saída atual de 1280x720 da TV, com medidas relativas ao viewport para adaptar a 1920x1080. A melhora de desempenho não foi medida por benchmark.



## Versão 1.3

Restauradas as camadas de céu, sol, lua, estrelas, nuvens, neblina, chuva e relâmpagos conforme o clima fornecido pelo site. Animações e transições do fundo voltaram a usar as regras originais. Painéis semitransparentes deixam o fundo visível. Mantidos o layout em duas telas e a remoção dos desfoques pesados. A cidade salva é preservada ao atualizar.



## Versão 1.4

Texto fixado em branco nas duas telas, controles e busca, independentemente do tema diurno/noturno do site. Rótulos menores, horários e informações de chuva sem redução de opacidade. Fundo dinâmico e layout em duas telas preservados. As cores internas do radar são controladas pelo RainViewer, em iframe externo. Endereço atual da TV do usuário: 192.168.1.3.



## Versão 1.6.0

- O botão de lupa foi substituído por Configurações, com busca para trocar a cidade salva.
- Configurações consulta a release mais recente do GitHub e informa quando há uma versão do APK disponível. A instalação continua pelo TV-LDZ, em Ajustes > Outros Apps.
- O seletor do controle remoto usa destaque índigo com contorno branco.
- O radar abre em tela cheia com enquadramento regional afastado (zoom 7) e botões para aproximar ou afastar.
- A tecla Voltar fecha Configurações ou o mapa antes de oferecer a saída do app.
- Essas mudanças estão no script de integração da TV, sem alterações nos arquivos do site.

Versão Android: 1.6.0 (versionCode 7), Android 8.0+ (API 26+), pacote br.com.ldz.tempotv.
## Versão 1.6.1

Corrigida a navegação do controle remoto para alcançar o botão de mapa em tela cheia; as setas agora controlam o mapa sem interferência da navegação entre telas. A engrenagem foi centralizada no próprio botão para manter o alinhamento visual. Mantém pacote, assinatura e compatibilidade Android 8+ da 1.6.0.

Versão Android: 1.6.1 (versionCode 8), pacote br.com.ldz.tempotv.