(function () {
    if (window.tempoTV) return;
    var input = document.getElementById('cidade');
    var search = document.getElementById('btnBuscar');
    if (!input || !search) return;
    var style = document.createElement('style');
    style.textContent = ':focus{outline:4px solid #ffc857!important;outline-offset:5px!important}body{padding:24px!important}input,button,a{font-size:22px!important;min-height:48px}.espaco-tela{display:none!important}' +
        '#tv-city-panel{position:fixed;z-index:100000;left:12%;right:12%;top:12%;padding:32px;background:#10243a;border:2px solid #66849e;border-radius:24px;box-shadow:0 0 0 100vmax #000b;color:white;max-height:70vh;overflow:auto}' +
        '#tv-city-panel p{margin:0 0 24px}#tv-city-panel input,#tv-city-panel button{display:block;width:100%;box-sizing:border-box;margin:16px 0}' +
        '#tv-city-toggle{position:fixed;z-index:9999;right:32px;top:24px;width:64px;height:56px;padding:8px;border-radius:18px;background:#10243a;color:white;border:2px solid #66849e;font-size:30px!important}' +
        '.topo{padding-right:84px!important}';
    document.head.appendChild(style);
    var gps = document.getElementById('btnGPS');
    if (gps) gps.style.display = 'none';
    Array.prototype.forEach.call(document.querySelectorAll('a[href]'), function (link) {
        if (/ipmet|cptec\.inpe|sat[eé]lite.*goes/i.test(link.href + ' ' + link.textContent)) link.remove();
    });
    var panel = document.createElement('div');
    panel.id = 'tv-city-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'Buscar cidade');
    panel.setAttribute('aria-modal', 'true');
    document.body.appendChild(panel);
    var hint = document.createElement('p');
    hint.textContent = 'Busque a cidade que deseja manter como padrão nesta TV.';
    panel.appendChild(hint);
    panel.appendChild(input);
    panel.appendChild(search);
    var cancel = document.createElement('button');
    cancel.textContent = 'Cancelar';
    panel.appendChild(cancel);
    var toggle = document.createElement('button');
    toggle.id = 'tv-city-toggle';
    toggle.textContent = '🔍';
    toggle.title = 'Trocar cidade';
    toggle.setAttribute('aria-label', 'Trocar cidade');
    document.body.appendChild(toggle);
    var refresh = document.getElementById('btnRefresh');
    var home = document.createElement('main');
    home.id = 'tv-home';
    var details = document.createElement('section');
    details.id = 'tv-details';
    document.body.appendChild(home);
    document.body.appendChild(details);
    home.appendChild(document.querySelector('.topo'));
    var columns = document.createElement('div');
    columns.id = 'tv-columns';
    home.appendChild(columns);
    columns.appendChild(document.querySelector('.resumo-clima'));
    columns.appendChild(document.querySelector('.radar'));
    home.appendChild(refresh);
    var next = document.createElement('p');
    next.id = 'tv-next';
    next.textContent = '↓ Após Atualizar, pressione para baixo para ver a previsão';
    home.appendChild(next);
    var back = document.createElement('button');
    back.id = 'tv-back';
    back.textContent = '↑ Voltar ao clima e radar';
    details.appendChild(back);
    Array.prototype.forEach.call(document.querySelectorAll('.previsao'), function (section) { details.appendChild(section); });
    var footer = document.querySelector('footer');
    if (footer) details.appendChild(footer);
    var radarFrame = document.getElementById('mapaRadar');
    radarFrame.setAttribute('tabindex', '-1');
    var page = 0;
    function showPage(number) {
        page = number;
        home.style.display = page ? 'none' : 'grid';
        details.style.display = page ? 'grid' : 'none';
        (page ? back : refresh).focus({preventScroll:true});
        window.scrollTo(0, 0);
    }
    back.addEventListener('click', function () { showPage(0); });
    var layout = document.createElement('style');
    layout.textContent = `
        html,body{margin:0!important;padding:0!important;width:100%;height:100%;overflow:hidden!important}
        html{background:#10243a}body{background:transparent!important;isolation:isolate}
        body *{box-sizing:border-box}
        body,#tv-home,#tv-home *,#tv-details,#tv-details *,#tv-city-panel,#tv-city-panel *,#tv-city-toggle{color:#fff!important;-webkit-text-fill-color:#fff!important}
        #tv-home .cidade,#tv-home .descricao,#tv-home .item span,#tv-details .hora,#tv-details .chuva,#tv-details .item span,#tv-details footer{opacity:1!important}
        #tv-city-panel input::placeholder{color:#fff!important;-webkit-text-fill-color:#fff!important;opacity:1!important}
        .controles,.espaco-tela{display:none!important}
        body *{backdrop-filter:none!important;-webkit-backdrop-filter:none!important}
        #tv-home *,#tv-details *{animation:none!important;transition:none!important;box-shadow:none!important}
        #tv-home,#tv-details{height:100vh;width:100%;padding:2.8vh 2.5vw;gap:1.6vh;overflow:hidden}
        #tv-home{display:grid;grid-template-rows:7vh minmax(0,1fr) 7vh 3vh}
        #tv-home .topo{margin:0!important;padding:0!important;text-align:left}
        #tv-home h1{font-size:4vh;margin:0;line-height:7vh}
        #tv-columns{display:grid;grid-template-columns:1fr 1fr;gap:2vw;min-height:0}
        #tv-columns .resumo-clima,#tv-columns .radar{margin:0!important;width:100%!important;height:100%;min-height:0;border-radius:20px;background:rgba(28,52,76,.78);overflow:hidden}
        #tv-columns .resumo-clima{padding:3vh 2vw;display:flex;flex-direction:column;justify-content:space-between}
        #tv-columns .cidade{font-size:3.5vh}
        #tv-columns .temperatura-principal{font-size:14vh;line-height:1.1;margin:0}
        #tv-columns .status{font-size:3vh;margin:0}
        #tv-columns .descricao,#tv-columns .info-chuva{font-size:2.6vh;margin:0}
        #tv-columns .dados-resumo{display:grid;grid-template-columns:repeat(3,1fr);gap:1vw;margin:1vh 0 0}
        #tv-columns .item{padding:1.5vh .5vw;background:#29445e;min-width:0}
        #tv-columns .item span{font-size:2.3vh}#tv-columns .item strong{font-size:3vh}
        #tv-columns .radar-container,#tv-columns #mapaRadar{height:100%!important;width:100%!important;min-height:0!important;margin:0!important;border:0;border-radius:20px}
        #tv-columns #mapaRadar{pointer-events:none}
        #btnRefresh,#tv-back{margin:0!important;min-height:0!important;width:100%;padding:1vh;background:#29445e;border:1px solid #66849e;border-radius:12px;color:white;font-size:3vh!important}
        #tv-next{margin:0;text-align:center;font-size:2.3vh;color:#b7cde0}
        #tv-city-toggle{top:2.8vh;right:2.5vw;width:7vh;height:6vh;min-height:0;font-size:3.5vh!important}
        #tv-details{display:none;grid-template-rows:6vh minmax(0,1fr) 20vh 3vh}
        #tv-back{width:calc(100% - 9vh)}
        #tv-details .previsao{margin:0!important;padding:0!important;min-height:0}
        #tv-details h2{font-size:3vh;margin:0 0 1vh}
        #tv-details br{display:none}
        #previsao12h{display:grid!important;grid-template-columns:repeat(6,minmax(0,1fr));grid-template-rows:repeat(2,minmax(0,1fr));gap:1vh 1vw;height:calc(100% - 5vh);overflow:hidden!important;padding:0!important}
        #previsao12h .previsao-card{width:auto!important;min-width:0!important;margin:0;padding:1vh!important;background:rgba(28,52,76,.78);border-radius:12px;display:flex;flex-direction:column;justify-content:center}
        .previsao-card .hora{font-size:2.3vh!important}.previsao-card .icone{font-size:3.8vh!important;margin:.3vh!important}.previsao-card .temp{font-size:3vh!important}.previsao-card .chuva{font-size:1.9vh!important}
        #tv-details .dados-resumo{display:grid;grid-template-columns:repeat(3,1fr);gap:1vw;margin:0}
        #tv-details .item{padding:1vh;background:rgba(28,52,76,.78)}#tv-details .item span{font-size:2.2vh}#tv-details .item strong{font-size:2.8vh}
        #tv-details footer{margin:0;padding:0;font-size:1.7vh}#tv-details footer p{margin:0}#tv-details footer br{display:none}
    `;
    document.head.appendChild(layout);
    var wheelTime = 0;
    document.addEventListener('wheel', function (event) {
        if (isOpen) return;
        event.preventDefault();
        if (Date.now() - wheelTime < 600) return;
        wheelTime = Date.now();
        showPage(event.deltaY > 0 ? 1 : 0);
    }, {passive:false});
    var isOpen = false;
    function city() {
        isOpen = true;
        panel.style.display = 'block';
        cancel.style.display = readCity() ? 'block' : 'none';
        input.focus();
    }
    function closeCity() {
        isOpen = false;
        input.blur();
        panel.style.display = 'none';
        if (window.TempoTVNative) window.TempoTVNative.hideKeyboard();
        showPage(0);
        toggle.focus({preventScroll:true});
        window.scrollTo(0, 0);
    }
    toggle.addEventListener('click', city);
    cancel.addEventListener('click', closeCity);
    window.tempoTV = {city:city};
    var storageKey = 'tempoLDZ.tv.city';
    function readCity() { try { return localStorage.getItem(storageKey); } catch (_) { return null; } }
    var pending = null;
    search.addEventListener('click', function () {
        var candidate = input.value.trim();
        var label = document.getElementById('cidadeAtual');
        if (!candidate || !label) return;
        if (pending) pending.disconnect();
        var observer = new MutationObserver(function () {
            try { localStorage.setItem(storageKey, candidate); } catch (_) {}
            observer.disconnect();
            closeCity();
        });
        pending = observer;
        observer.observe(label, {childList:true, subtree:true, characterData:true});
        setTimeout(function () { observer.disconnect(); }, 15000);
    }, true);
    var saved = readCity();
    panel.style.display = 'none';
    if (saved) { input.value = saved; closeCity(); search.click(); }
    else { document.getElementById('cidadeAtual').textContent = 'Escolha sua cidade'; city(); }
    document.addEventListener('keydown', function (event) {
        var directions = ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'];
        if (directions.indexOf(event.key) < 0) return;
        var fullscreenMap = document.getElementById('tv-map-fullscreen');
        if (fullscreenMap && fullscreenMap.style.display === 'block') return;
        if (!isOpen) {
            event.preventDefault();
            var mapOpen = document.getElementById('tv-map-open');
            var active = document.activeElement;
            if (page === 0) {
                if (event.key === 'ArrowDown') {
                    if (active === toggle || active !== refresh && active !== mapOpen) refresh.focus();
                    else if (active === refresh || active === mapOpen) showPage(1);
                } else if (event.key === 'ArrowUp') {
                    if (active === mapOpen || active === refresh) toggle.focus();
                    else if (page === 1) showPage(0);
                    else toggle.focus();
                } else if (event.key === 'ArrowRight') {
                    if (active === refresh) { if (mapOpen && !mapOpen.disabled) mapOpen.focus(); else toggle.focus(); }
                    else toggle.focus();
                } else if (event.key === 'ArrowLeft') {
                    if (active === toggle) { if (mapOpen && !mapOpen.disabled) mapOpen.focus(); else refresh.focus(); }
                    else refresh.focus();
                }
            } else {
                if (event.key === 'ArrowUp') showPage(0);
                else if (event.key === 'ArrowDown') back.focus();
                else if (event.key === 'ArrowRight' || event.key === 'ArrowLeft') back.focus();
            }
            return;
        }
        if (document.activeElement === input) {
            if (event.key === 'ArrowDown') { event.preventDefault(); search.focus(); }
            return;
        }
        var dx = event.key === 'ArrowRight' ? 1 : event.key === 'ArrowLeft' ? -1 : 0;
        var dy = event.key === 'ArrowDown' ? 1 : event.key === 'ArrowUp' ? -1 : 0;
        var current = document.activeElement;
        var rect = current.getBoundingClientRect();
        var cx = rect.left + rect.width/2, cy = rect.top + rect.height/2;
        var best = null, score = Infinity;
        Array.prototype.forEach.call((isOpen ? panel : document).querySelectorAll('button,input,a[href]'), function (item) {
            var r = item.getBoundingClientRect();
            if (item === current || !r.width || !r.height || item.disabled) return;
            var x = r.left + r.width/2 - cx, y = r.top + r.height/2 - cy;
            var forward = x*dx + y*dy;
            if (forward <= 0) return;
            var distance = forward + Math.abs(x*dy - y*dx)*2;
            if (distance < score) { score = distance; best = item; }
        });
        event.preventDefault();
        if (best) { best.focus(); best.scrollIntoView({block:'nearest'}); }
        else window.scrollBy(dx*160, dy*240);
    });
})();
