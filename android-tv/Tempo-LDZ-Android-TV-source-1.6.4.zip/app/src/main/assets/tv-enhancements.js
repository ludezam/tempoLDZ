(function () {
    var toggle = document.getElementById('tv-city-toggle');
    if (!toggle || !window.tempoTV) return;

    var style = document.createElement('style');
    style.textContent =
        ':focus{outline:none!important;box-shadow:none!important}' +
        '#tv-settings-panel button:focus,#tv-city-panel button:focus,#tv-map-controls button:focus,#tv-map-open:focus,#tv-city-toggle:focus,#btnRefresh:focus,#tv-back:focus{background-color:#fff!important;color:#10243a!important;-webkit-text-fill-color:#10243a!important}' +
        '#tv-city-toggle{display:flex!important;align-items:center;justify-content:center;line-height:1;padding:0!important;box-sizing:border-box;font-size:3.6vh!important;border-color:#7665ff!important}' +
        '#tv-settings-panel{position:fixed;z-index:200000;left:18%;right:18%;top:14%;padding:3vh 3vw;background:#10243a;border:2px solid #7665ff;border-radius:22px;box-shadow:0 0 0 100vmax #000b;color:#fff;max-height:72vh;overflow:auto}' +
        '#tv-settings-panel h2{font-size:4vh;margin:0 0 2vh}' +
        '#tv-settings-panel button{display:block;width:100%;min-height:7vh;margin:1.5vh 0;padding:1vh 1.4vw;border:2px solid #5268ff;border-radius:12px;background:#1b3551;color:white;font-size:2.7vh!important}' +
        '#tv-update-status{min-height:3vh;margin:1.5vh 0;font-size:2.2vh;line-height:1.4;color:#fff}' +
        '#tv-columns .radar{position:relative}#tv-map-open{position:absolute;z-index:10;top:1vh;right:1vw;min-height:6vh;padding:1vh 1.2vw;border:2px solid #66849e;border-radius:12px;background:#10243a;color:#fff;font-size:2.2vh!important}' +
        '#tv-map-fullscreen{position:fixed;inset:0;z-index:300000;background:#06111f}' +
        '#tv-map-fullscreen #mapaRadar{position:absolute;inset:0;width:100%;height:100%;border:0;pointer-events:auto!important;z-index:1}' +
        '#tv-map-controls{position:absolute;z-index:2;top:2vh;right:2vw;display:flex;align-items:center;gap:.7vw}' +
        '#tv-map-controls button{min-width:6vh;min-height:6vh;padding:.8vh 1vw;border:0;border-radius:8px;background:#18324a;color:white;font-size:2.2vh!important}' +
        '#tv-map-zoom-label{padding:.8vh 1vw;border-radius:8px;background:#18324a;color:white;font-size:2vh}';
    document.head.appendChild(style);

    toggle.textContent = '⚙';
    toggle.title = 'Configurações';
    toggle.setAttribute('aria-label', 'Configurações');

    var radar = document.querySelector('.radar-container');
    var radarFrame = document.getElementById('mapaRadar');
    if (!radar || !radarFrame) return;

    var settingsPanel = document.createElement('section');
    settingsPanel.id = 'tv-settings-panel';
    settingsPanel.setAttribute('role', 'dialog');
    settingsPanel.setAttribute('aria-modal', 'true');
    settingsPanel.setAttribute('aria-label', 'Configurações do Tempo LDZ');
    settingsPanel.style.display = 'none';
    settingsPanel.innerHTML = '<h2>Configurações</h2>';
    var cityButton = document.createElement('button');
    cityButton.type = 'button';
    cityButton.textContent = 'Buscar outra cidade';
    var updateButton = document.createElement('button');
    updateButton.type = 'button';
    updateButton.textContent = 'Buscar atualizações do aplicativo';
    var status = document.createElement('p');
    status.id = 'tv-update-status';
    status.setAttribute('role', 'status');
    var closeSettingsButton = document.createElement('button');
    closeSettingsButton.type = 'button';
    closeSettingsButton.textContent = 'Fechar';
    settingsPanel.append(cityButton, updateButton, status, closeSettingsButton);
    document.body.appendChild(settingsPanel);

    var settingsOpen = false;
    var cityOpen = false;
    function openSettings() {
        cityOpen = false;
        settingsOpen = true;
        var label = document.getElementById('cidadeAtual');
        status.textContent = 'Cidade padrão: ' + (label ? label.textContent : 'não definida');
        settingsPanel.style.display = 'block';
        cityButton.focus();
    }
    function closeSettings() {
        settingsOpen = false;
        settingsPanel.style.display = 'none';
        toggle.focus({preventScroll:true});
    }
    toggle.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopImmediatePropagation();
        openSettings();
    }, true);
    cityButton.addEventListener('click', function () {
        closeSettings();
        cityOpen = true;
        window.tempoTV.city();
    });
    closeSettingsButton.addEventListener('click', closeSettings);

    function parts(value) {
        return String(value || '').replace(/^[vV]/, '').split(/[.-]/).map(function (item) {
            var number = parseInt(item, 10);
            return isNaN(number) ? 0 : number;
        });
    }
    function compare(a, b) {
        var aa = parts(a), bb = parts(b);
        for (var i = 0; i < Math.max(aa.length, bb.length); i++) {
            var x = aa[i] || 0, y = bb[i] || 0;
            if (x !== y) return x > y ? 1 : -1;
        }
        return 0;
    }
    updateButton.addEventListener('click', function () {
        updateButton.disabled = true;
        status.textContent = 'Consultando a versão mais recente no GitHub…';
        var installed = window.TempoTVNative ? window.TempoTVNative.getVersionName() : '1.6.4';
        fetch('https://api.github.com/repos/ludezam/tempoLDZ/releases/latest', {
            headers: {Accept:'application/vnd.github+json'}
        }).then(function (response) {
            if (!response.ok) throw new Error('Falha na consulta');
            return response.json();
        }).then(function (release) {
            var apk = (release.assets || []).some(function (asset) { return asset.name === 'Tempo-LDZ.apk'; });
            if (!apk) throw new Error('APK ausente');
            var latest = release.tag_name || '';
            if (compare(latest, installed) > 0) {
                status.textContent = 'A versão ' + latest + ' está disponível. Instale pelo TV-LDZ > Ajustes > Outros Apps.';
            } else {
                status.textContent = 'Este app está na versão ' + installed + '. A release mais recente é ' + latest + '.';
            }
        }).catch(function () {
            status.textContent = 'Não foi possível consultar a release. Confira a conexão e tente novamente.';
        }).finally(function () {
            updateButton.disabled = false;
        });
    });

    var mapButton = document.createElement('button');
    mapButton.id = 'tv-map-open';
    mapButton.type = 'button';
    mapButton.textContent = '⛶ Mapa em tela cheia';
    mapButton.setAttribute('aria-label', 'Abrir mapa regional em tela cheia');
    mapButton.disabled = !radarFrame.getAttribute('src');
    radar.appendChild(mapButton);

    var mapScreen = document.createElement('section');
    mapScreen.id = 'tv-map-fullscreen';
    mapScreen.setAttribute('role', 'dialog');
    mapScreen.setAttribute('aria-modal', 'true');
    mapScreen.setAttribute('aria-label', 'Radar em tela cheia');
    mapScreen.style.display = 'none';
    var radarParent = radarFrame.parentNode;
    var radarPlaceholder = document.createComment('posição original do radar');
    radarParent.insertBefore(radarPlaceholder, radarFrame);
    var controls = document.createElement('div');
    controls.id = 'tv-map-controls';
    var zoomOut = document.createElement('button');
    zoomOut.type = 'button';
    zoomOut.textContent = '−';
    zoomOut.title = 'Afastar';
    zoomOut.setAttribute('aria-label', 'Afastar o mapa');
    var zoomText = document.createElement('span');
    zoomText.id = 'tv-map-zoom-label';
    var zoomIn = document.createElement('button');
    zoomIn.type = 'button';
    zoomIn.textContent = '+';
    zoomIn.title = 'Aproximar';
    zoomIn.setAttribute('aria-label', 'Aproximar o mapa');

    var mapReload = document.createElement('button');
    mapReload.type = 'button';
    mapReload.textContent = 'Recarregar radar';
    mapReload.setAttribute('aria-label', 'Recarregar mapa e camada de chuva');
    var mapClose = document.createElement('button');
    mapClose.type = 'button';
    mapClose.textContent = 'Fechar';
    mapClose.setAttribute('aria-label', 'Fechar mapa em tela cheia');
    controls.append(zoomOut, zoomText, zoomIn, mapReload, mapClose);
    mapScreen.append(controls);
    document.body.appendChild(mapScreen);

    var zoom = 7;
    function mapUrl(source, level) {
        try {
            var url = new URL(source, window.location.href);
            var loc = url.searchParams.get('loc');
            if (!loc) return '';
            var coordinates = loc.split(',');
            if (coordinates.length < 2) return '';
            coordinates[2] = String(level);
            url.searchParams.set('loc', coordinates.join(','));
            return url.toString();
        } catch (_) { return ''; }
    }
    function setZoom(level) {
        zoom = Math.max(5, Math.min(12, level));
        var current = radarFrame.getAttribute('src') || radarFrame.src;
        var source = mapUrl(current, zoom);
        if (!source) {
            mapReload.textContent = 'Radar carregando…';
            return;
        }
        if (source !== current) radarFrame.setAttribute('src', source);
        zoomText.textContent = 'Zoom ' + zoom;
    }
    function normalizeRadarSource() {
        var current = radarFrame.getAttribute('src') || '';
        var source = mapUrl(current, 7);
        if (source && source !== current) {
            zoom = 7;
            radarFrame.setAttribute('src', source);
        }
        mapButton.disabled = !current;
    }
    function openMap() {
        if (mapButton.disabled) return;
        settingsOpen = false;
        settingsPanel.style.display = 'none';
        setZoom(7);
        radarFrame.setAttribute('tabindex', '-1');
        mapScreen.insertBefore(radarFrame, controls);
        mapScreen.style.display = 'block';
        mapClose.focus();
    }
    function closeMap() {
        mapScreen.style.display = 'none';
        radarParent.insertBefore(radarFrame, radarPlaceholder);
        mapButton.focus({preventScroll:true});
    }
    mapButton.addEventListener('click', openMap);
    mapClose.addEventListener('click', closeMap);
    zoomOut.addEventListener('click', function () { setZoom(zoom - 1); zoomOut.focus(); });
    zoomIn.addEventListener('click', function () { setZoom(zoom + 1); zoomIn.focus(); });
    mapInteract.addEventListener('click', function () {
        radarFrame.focus();
    });
    mapReload.addEventListener('click', function () {
        var source = radarFrame.getAttribute('src') || radarFrame.src;
        if (!source || source === 'about:blank') return;
        mapReload.disabled = true;
        mapReload.textContent = 'Carregando…';
        radarFrame.setAttribute('src', 'about:blank');
        setTimeout(function () {
            radarFrame.setAttribute('src', source);
            mapReload.textContent = 'Recarregar radar';
            mapReload.disabled = false;
            mapReload.focus();
        }, 120);
    });
    radarFrame.setAttribute('loading', 'eager');
    radarFrame.setAttribute('tabindex', '-1');
    radarFrame.addEventListener('focus', function () {
        if (mapScreen.style.display === 'block') mapClose.focus();
    });
    radarFrame.addEventListener('load', function () {
        if (!mapReload.disabled) mapReload.textContent = 'Recarregar radar';
    });
    var radarObserver = new MutationObserver(normalizeRadarSource);
    radarObserver.observe(radarFrame, {attributes:true, attributeFilter:['src']});
    normalizeRadarSource();
    function focusMove(scope, key) {
        var current = document.activeElement;
        var rect = current.getBoundingClientRect();
        var cx = rect.left + rect.width / 2, cy = rect.top + rect.height / 2;
        var dx = key === 'ArrowRight' ? 1 : key === 'ArrowLeft' ? -1 : 0;
        var dy = key === 'ArrowDown' ? 1 : key === 'ArrowUp' ? -1 : 0;
        var best = null, bestScore = Infinity;
        Array.prototype.forEach.call(scope.querySelectorAll('button'), function (item) {
            var r = item.getBoundingClientRect();
            if (item === current || item.disabled || !r.width || !r.height) return;
            var x = r.left + r.width / 2 - cx, y = r.top + r.height / 2 - cy;
            var forward = x * dx + y * dy;
            if (forward <= 0) return;
            var score = forward + Math.abs(x * dy - y * dx) * 2;
            if (score < bestScore) { bestScore = score; best = item; }
        });
        if (best) best.focus();
    }
    function closeCityPanel() {
        var panel = document.getElementById('tv-city-panel');
        if (panel) {
            var buttons = panel.querySelectorAll('button');
            if (buttons.length) buttons[buttons.length - 1].click();
        }
        cityOpen = false;
    }
    var oldBack = window.tempoTV.back;
    window.tempoTV.settings = openSettings;
    window.tempoTV.back = function () {
        if (mapScreen.style.display === 'block') { closeMap(); return true; }
        if (settingsOpen) { closeSettings(); return true; }
        if (cityOpen) { closeCityPanel(); return true; }
        if (typeof oldBack === 'function' && oldBack()) return true;
        return false;
    };

    document.addEventListener('keydown', function (event) {
        var back = event.key === 'Escape' || event.key === 'Backspace' || event.keyCode === 4;
        if (back && (settingsOpen || cityOpen || mapScreen.style.display === 'block')) {
            event.preventDefault();
            event.stopImmediatePropagation();
            window.tempoTV.back();
            return;
        }
        var arrows = ['ArrowUp','ArrowDown','ArrowLeft','ArrowRight'];
        if (arrows.indexOf(event.key) < 0) return;
        if (settingsOpen) {
            event.preventDefault();
            event.stopImmediatePropagation();
            focusMove(settingsPanel, event.key);
        } else if (mapScreen.style.display === 'block') {
            event.preventDefault();
            event.stopImmediatePropagation();
            if (document.activeElement === radarFrame) mapClose.focus();
            else focusMove(controls, event.key);
        }
    }, true);

    if (document.getElementById('tv-city-panel') &&
        document.getElementById('tv-city-panel').style.display !== 'none') cityOpen = true;
})();




