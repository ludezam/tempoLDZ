package br.com.ldz.tempotv;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceError;
import android.widget.Button;
import android.widget.LinearLayout;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView web;
    private LinearLayout root;
    private static final String HOME = "https://ludezam.github.io/tempoLDZ/";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        getWindow().getDecorView().setSystemUiVisibility(5894);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        setContentView(root);
        web = new WebView(this);
        web.setBackgroundColor(0xff10243a);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setGeolocationEnabled(false);
        web.getSettings().setAllowFileAccess(false);
        web.getSettings().setAllowContentAccess(false);
        web.addJavascriptInterface(new Object() {
            @android.webkit.JavascriptInterface public String getVersionName() {
                try { return getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
                catch (Exception error) { return "1.6.0"; }
            }
            @android.webkit.JavascriptInterface public void hideKeyboard() {
                runOnUiThread(() -> {
                    android.view.inputmethod.InputMethodManager keyboard =
                        (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                    keyboard.hideSoftInputFromWindow(web.getWindowToken(), 0);
                });
            }
        }, "TempoTVNative");
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return request.isForMainFrame() && !isHome(request.getUrl().toString());
            }
            @Override public void onPageFinished(WebView view, String url) {
                if (!isHome(url)) return;
                try {
                    java.io.ByteArrayOutputStream out = new java.io.ByteArrayOutputStream();
                    byte[] buffer = new byte[4096];
                    for (String asset : new String[]{"tv.js", "tv-enhancements.js"}) {
                        try (InputStream stream = getAssets().open(asset)) {
                            int count;
                            while ((count = stream.read(buffer)) != -1) out.write(buffer, 0, count);
                        }
                        out.write(10);
                    }
                    web.evaluateJavascript(out.toString("UTF-8"), null);
                } catch (Exception error) {
                    new AlertDialog.Builder(MainActivity.this).setMessage("Não foi possível iniciar os controles da TV.")
                        .setPositiveButton("Recarregar", (dialog, which) -> web.reload()).show();
                }
            }
            @Override public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (!request.isForMainFrame()) return;
                root.removeAllViews();
                Button retry = new Button(MainActivity.this);
                retry.setText("Sem conexão. Pressione OK para tentar novamente");
                retry.setOnClickListener(v -> { root.removeAllViews(); attachWeb(); web.loadUrl(HOME); });
                root.addView(retry);
                retry.requestFocus();
            }
        });
        attachWeb();
        web.loadUrl(HOME);
    }
    private boolean isHome(String url) {
        android.net.Uri uri = android.net.Uri.parse(url);
        return "https".equals(uri.getScheme()) && "ludezam.github.io".equals(uri.getHost())
            && uri.getPath() != null && uri.getPath().startsWith("/tempoLDZ/");
    }
    private void attachWeb() {
        root.addView(web, new LinearLayout.LayoutParams(-1, -1));
        web.requestFocus();
    }
    @Override public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getKeyCode() == KeyEvent.KEYCODE_MENU) {
            if (event.getAction() == KeyEvent.ACTION_DOWN)
                web.evaluateJavascript("window.tempoTV && window.tempoTV.settings()", null);
            return true;
        }
        return super.dispatchKeyEvent(event);
    }
    @Override public void onBackPressed() {
        if (web != null) {
            web.evaluateJavascript("(function(){return window.tempoTV && window.tempoTV.back ? window.tempoTV.back() : false})()", result -> {
                if (!"true".equals(result)) showExitDialog();
            });
        } else showExitDialog();
    }
    private void showExitDialog() {
        new AlertDialog.Builder(this).setTitle("Sair do Tempo LDZ?")
            .setNegativeButton("Continuar", null)
            .setPositiveButton("Sair", (dialog, which) -> finish()).show();
    }
    @Override protected void onPause() { web.onPause(); super.onPause(); }
    @Override protected void onResume() { super.onResume(); if (web != null) web.onResume(); }
    @Override protected void onDestroy() { web.destroy(); super.onDestroy(); }
}
